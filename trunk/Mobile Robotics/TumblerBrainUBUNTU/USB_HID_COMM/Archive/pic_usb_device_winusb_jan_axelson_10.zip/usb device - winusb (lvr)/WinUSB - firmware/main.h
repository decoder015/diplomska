/********************************************************************
 FileName:      main.c
 Dependencies:  See INCLUDES section
 Processor:		PIC18 USB Microcontrollers
 Hardware:		The code is natively intended to be used on the following
 				hardware platforms: PICDEM� FS USB Demo Board, 
 				The firmware may be
 				modified for use on other USB platforms by editing the
 				HardwareProfile.h file.
 Compiler:  	Microchip C18 (for PIC18)
 Company:		Jan Axelson

 Software License Agreement:

Licensor grants any person obtaining a copy of this software ("You") 
a worldwide, royalty-free, non-exclusive license, for the duration of 
the copyright, free of charge, to store and execute the Software in a 
computer system and to incorporate the Software or any portion of it 
in computer programs You write.   
 
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.


********************************************************************
 File Description:

 Change History:
  Rev   Date        Description
  1.0   8/15/2009    Original version 

********************************************************************/
#ifndef USER_H
#define USER_H
         
#define WINUSB_REQUEST_1     0x01
#define WINUSB_REQUEST_2     0x02

#define WINUSB_CONTROL_WRITE_PFUNC &WINUSB_CONTROL_WRITE_HANDLER
#define WINUSB_CONTROL_WRITE_BUFFER &winusb_control_write_buffer[0]

/** P U B L I C  P R O T O T Y P E S *****************************************/
   
#endif // USB_USE_WINUSB
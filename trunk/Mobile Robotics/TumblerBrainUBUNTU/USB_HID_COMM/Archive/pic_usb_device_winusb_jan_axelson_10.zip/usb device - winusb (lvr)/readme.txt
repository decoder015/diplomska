WinUSB Firmware for Microchip Full-speed USB Chips
Using Microchip USB Framework V2.6a

Jan Axelson
www.Lvr.com
jan (at) Lvr.com

8/17/09
V0.9
4/22/10
V1.0

PROJECT DESCRIPTION

The firmware in this zip file demonstrates control, bulk, and interrupt transfers
on a USB device that uses the Windows WinUSB driver. The firmware does the following:

Receives 2 bytes in a vendor-defined control write transfer.

Sends back the received data in a vendor-defined control read transfer. 

Receives up to 64 bytes on a bulk OUT endpoint.

Sends back the received data via a bulk IN endpoint. 

Receives 2 bytes on an interrupt OUT endpoint.

Sends back the received data via an interrupt IN endpoint. 

The firmware is adapted from Microchip's WinUSB Simple Demo.

The project has been tested on the PICDEM� FS USB DEMONSTRATION BOARD

MORE INFORMATION

This application, host applications to communicate with the device, and more about 
USB and WinUSB are available from:

www.Lvr.com/winusb.htm

HOW TO CREATE THE PROJECT

Download and install the Microchip PIC18F and PIC24F Microchip Application Libraries  
V2.6a. 

The Libraries are here (or search for "Microchip Application Libraries"):
 
The installation creates a directory structure under "Microchip Solutions", 
assuming you use the default directory.

The zip file that contains this readme file contains a project directory 
for the WinUSB application. The directory is:

USB Device - WinUSB (LVR)

Copy this directory as a subdirectory of the Microchip Solutions directory 
so you end up with:

Microchip Solutions\USB Device - WinUSB (LVR)





﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace test_hid_out
{
    public partial class Form1 : Form
    {
        public const Int32 WM_DEVICECHANGE = 0X219;


        internal void OnDeviceChange(Message m)
        {
            InitializeHID();
        }

        protected override void WndProc(ref Message m)
        {
            try
            {
                //  The OnDeviceChange routine processes WM_DEVICECHANGE messages.

                if (m.Msg == WM_DEVICECHANGE)
                {
                    OnDeviceChange(m);
                }

                //  Let the base form process the message.

                base.WndProc(ref m);
            }
            catch (Exception ex)
            {
                //  DisplayException(this.Name, ex);
                throw;
            }
        }



        public void InitializeHID()
        {
            if (suhid1.CanFindTheHid())
            {
                // Byte[] 
                MyOutputReportBuffer = new Byte[64];
                MyOutputReportBuffer[0] = 0;
                MyOutputReportBuffer[1] = 100;
                label2.Text = "push button to send data";
                button2.Enabled = true;
                label1.Text = "trovato vid" + suhid1.TheVid + "pid" + suhid1.ThePid;
            }
            else
            {

                button2.Enabled = false;
                label1.Text = "non trovato vid" + suhid1.TheVid + "pid" + suhid1.ThePid;
                label2.Text = "can't send data";

            }
        }
       Byte[] MyOutputReportBuffer = null;
        public Form1()
        {
            InitializeComponent();
            InitializeHID();
         
        }

        private void button2_Click(object sender, EventArgs e)
        {
            label2.Text = "sending [0]=" + MyOutputReportBuffer[0].ToString() +
                     " [1]=" + MyOutputReportBuffer[1].ToString();     
            suhid1.WriteOutputReport(MyOutputReportBuffer);
            MyOutputReportBuffer[0]++;
            MyOutputReportBuffer[1]++;
        }

       
    }
}

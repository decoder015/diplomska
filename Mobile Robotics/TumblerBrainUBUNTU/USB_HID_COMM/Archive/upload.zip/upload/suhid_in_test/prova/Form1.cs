﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace prova
{
    public partial class Form1 : Form
    {
        public const Int32 WM_DEVICECHANGE = 0X219;


        internal void OnDeviceChange(Message m)
        {
            label1.Text = "cambiato!";
            /*
            Debug.WriteLine("WM_DEVICECHANGE");

            try
            {
                if ((m.WParam.ToInt32() == DeviceManagement.DBT_DEVICEARRIVAL))
                {

                    //  If WParam contains DBT_DEVICEARRIVAL, a device has been attached.

                    Debug.WriteLine("A device has been attached.");

                    //  Find out if it's the device we're communicating with.

                    if (MyDeviceManagement.DeviceNameMatch(m, myDevicePathName))
                    {
                        lstResults.Items.Add("My device attached.");
                    }

                }
                else if ((m.WParam.ToInt32() == DeviceManagement.DBT_DEVICEREMOVECOMPLETE))
                {

                    //  If WParam contains DBT_DEVICEREMOVAL, a device has been removed.

                    Debug.WriteLine("A device has been removed.");

                    //  Find out if it's the device we're communicating with.

                    if (MyDeviceManagement.DeviceNameMatch(m, myDevicePathName))
                    {

                        lstResults.Items.Add("My device removed.");

                        //  Set MyDeviceDetected False so on the next data-transfer attempt,
                        //  FindTheHid() will be called to look for the device 
                        //  and get a new handle.

                        FrmMy.myDeviceDetected = false;
                    }
                }
                ScrollToBottomOfListBox();
            }
            catch (Exception ex)
            {
                DisplayException(this.Name, ex);
                throw;
            }
      */  }         
        
        protected override void WndProc(ref Message m)
        {
            try
            {
                //  The OnDeviceChange routine processes WM_DEVICECHANGE messages.

                if (m.Msg == WM_DEVICECHANGE)
                {
                    OnDeviceChange(m);
                }

                //  Let the base form process the message.

                base.WndProc(ref m);
            }
            catch (Exception ex)
            {
              //  DisplayException(this.Name, ex);
                throw;
            }
        }  
        public Form1()
        {

            InitializeComponent();
            label1.Text =
                "waiting for connection to" + suhid1.TheVid + "pid"
                + suhid1.ThePid;
            do { } while (!suhid1.CanFindTheHid()
                );
            if (suhid1.CanFindTheHid())
            { label1.Text = "found vid" + suhid1.TheVid + "pid" + suhid1.ThePid; }
            else { label1.Text = "not found vid" + suhid1.TheVid + "pid" + suhid1.ThePid; }

            suhid1.StartReceiving();
        }

        private void suhid1_BytesAreReceived()
        {
            label2.Text = suhid1.inputReportBuffer[1].ToString();
           
        }
    }
}

//ver 4 funziona con evento in inerrupt

//mettendo large mem model in user.. si toglie innocua diagnostica
//su printf //cala di pochissimo la velocit� (v.cdcsample)
/** I N C L U D E S **********************************************************/
#include "usp18f4550.h" 
#include "usbfw\typedefs.h"
#include "usbfw\usb.h"
#include <stdio.h>
#include "uslcd.h"
#include "usprintf.h"
#include "user.h"
#include "ustimer.h"

/** V A R I A B L E S ********************************************************/
#define ROMAddr 1
#pragma udata
unsigned char input_buffer[65],output_buffer[65],buffer[30]="Benvenuti in Picboard!   ",fisso[20]="ITIAV SEZ A TELE";
volatile unsigned char flag,lcdon,Event0On=0,Analog5VOn=1;
/** P R I V A T E  P R O T O T Y P E S ***************************************/
void MyIntHandler(void);
void GestioneBoard(void);
#pragma interruptlow MyLowISR
void
MyLowISR(void)
{
  }	

#pragma interruptlow MyHighISR //devo metter low anche se high??????
void
MyHighISR (void)
{//if (Event0On) 
MyIntHandler(); 
  }	

#pragma code highVector= 0x2008
void HighVector (void)
{
   _asm
       goto MyHighISR       // jump to interrupt routine
   _endasm
}

#pragma code
#pragma code lowVector = 0x2018
void LowVector (void)
{
   _asm
       goto MyLowISR       // jump to interrupt routine
   _endasm
}


/** D E C L A R A T I O N S **************************************************/
#pragma code
void UserInit(void)
{lcd_init();
lcd_goto(16);
printf("lcd2pic");
Init_Timer(0,2,0);
TMR0H=Pr0H;TMR0L=Pr0L;
INTCONbits.TMR0IE=1;
	T0CONbits.TMR0ON=1;
INTCONbits.INT0IE=1; 
INTCONbits.PEIE=1;
 INTCONbits.GIE=1;
}//end UserInit


void ProcessIO(void)
{   
  
    if((usb_device_state < CONFIGURED_STATE)||(UCONbits.SUSPND==1)) return;
    
  GestioneBoard();
    
}//end ProcessIO

unsigned char Cmd;
unsigned char NTest=0;
void GestioneBoard(void)

{
 }

volatile unsigned char Cont=0;
/***************************************************************************************/
void
MyIntHandler ()
{

{Cont++;
INTCONbits.TMR0IF=0; 
TMR0H=Pr0H;TMR0L=Pr0L;
output_buffer[0]=Cont;//payload per debug
output_buffer[1]=1;//payload per debug;
output_buffer[2]=2;
 output_buffer[3]=0;
lcd_goto(0);
printf("%d    ",Cont);
      if(!mHIDTxIsBusy())  HIDTxReport((char*)output_buffer);
              //   else PutInFIFO((char*)output_buffer); //riprova al giro dopo del mainloop
 
   

} 

}







#ifndef USER_H
#define USER_H
#define vFirmWareVersion 4
#define kTest 11
#define kPutDisplayChar 1
#define kPutDisplayByte 2
#define kClearDisplay 3
#define kAnalog 4
#define kLcd 5
#define kPCOn 6
#define kPCOff 7
 #define kPortA 8
 #define kPortB 9
 #define kPortD 10
 #define kEvent0On 12
 #define kEvent0Off 13
 #define kAnalog5V 14
 #define kAnalogVVar 15
#define kGetVersion 16
#define kPutEPROMChar 17
#define kBlocking 18
#define kAnswer 64
#define kQuery 128
#define kEvent0 32
#define kEvent1 33
#define kEvent2 34
/** P U B L I C  P R O T O T Y P E S *****************************************/
void UserInit(void);
void ProcessIO(void);

#endif //USER_H

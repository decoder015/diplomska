//NORMALMENTE NON MODIFICARE!!!!!!!!!!!!!!!
//ricordare di sistemare nelle build options di mplab 18 -DHID33
//se si cambiano percorsi ribildare le lib
#include "usheader.h"
#include "usp18f4550.h" 
#include "usbfw\usbdrv.h"
#include "user\user.h"

#pragma udata

/** P R I V A T E  P R O T O T Y P E S ***************************************/
static void InitializeSystem(void);
void USBTasks(void);
/** D E C L A R A T I O N S **************************************************/
#pragma code


void main(void)
{
   InitializeSystem();
    while(1)
    {
        USBTasks();         
        ProcessIO();        
   }//end while

}//end main


static void InitializeSystem(void)
{
    ADCON1 |= 0x0F;                 // Default all pins to digital
    
    #if defined(USE_USB_BUS_SENSE_IO)
    tris_usb_bus_sense = INPUT_PIN; // 
    #endif
    
    #if defined(USE_SELF_POWER_SENSE_IO)
    tris_self_power = INPUT_PIN;
    #endif
    
    mInitializeUSBDriver();         // See usbdrv.h
    
    UserInit();                     // See user.c & .h

}//end InitializeSystem


void USBTasks(void)
{
  
    USBCheckBusStatus();  // Must use polling method
   // if(UCFGbits.UTEYE!=1)   //TOLTO 2005
        USBDriverService();   //in usbdrv  Interrupt or polling method
                              //da qui raccatta tutto quello che succede
                              //in particolare un epo setup da gestire
   }// end USBTasks

//ver 4 funziona con evento in inerrupt

//mettendo large mem model in user.. si toglie innocua diagnostica
//su printf //cala di pochissimo la velocit� (v.cdcsample)
/** I N C L U D E S **********************************************************/
#include "usp18f4550.h" 
#include "usbfw\typedefs.h"
#include "usbfw\usb.h"
#include <stdio.h>
#include "uslcd.h"
#include "usprintf.h"
#include "user.h"

/** V A R I A B L E S ********************************************************/
#define ROMAddr 1
#pragma udata
unsigned char input_buffer[65],output_buffer[65],buffer[30]="Benvenuti in Picboard!   ",fisso[20]="ITIAV SEZ A TELE";
volatile unsigned char flag,lcdon,Event0On=0,Analog5VOn=1;
/** P R I V A T E  P R O T O T Y P E S ***************************************/
void MyIntHandler(void);
void GestioneBoard(void);
#pragma interruptlow MyLowISR
void
MyLowISR(void)
{
  }	

#pragma interruptlow MyHighISR //devo metter low anche se high??????
void
MyHighISR (void)
{//if (Event0On) 
MyIntHandler(); 
  }	

#pragma code highVector= 0x2008
void HighVector (void)
{
   _asm
       goto MyHighISR       // jump to interrupt routine
   _endasm
}

#pragma code
#pragma code lowVector = 0x2018
void LowVector (void)
{
   _asm
       goto MyLowISR       // jump to interrupt routine
   _endasm
}


/** D E C L A R A T I O N S **************************************************/
#pragma code
void UserInit(void)
{unsigned char flag;

lcdon=lcd_init();

lcd_goto(0); printf("attesa    ");


 }//end UserInit


void ProcessIO(void)
{   
  
    if((usb_device_state < CONFIGURED_STATE)||(UCONbits.SUSPND==1)) return;
    
  GestioneBoard();
    
}//end ProcessIO

unsigned char Cmd;
unsigned char NTest=0;
void GestioneBoard(void)

{unsigned char CmdSwitch;
    Cmd=0;
    Cmd=HIDRxReport((char*)input_buffer); 
 if (Cmd)
   {  lcd_goto(0);
printf("%d/%d/%d/%d/  ",input_buffer[0],input_buffer[1],input_buffer[2],input_buffer[3]);
lcd_goto(16);
printf("%d/%d/%d/%d/  ",input_buffer[4],input_buffer[5],input_buffer[6],input_buffer[7]);
}

  /*  if (Cmd)
     {CmdSwitch=input_buffer[2];
          if (CmdSwitch>=kQuery){ //risposte a richieste byte
          CmdSwitch=CmdSwitch-kQuery; 
        
                //spedisce al pc outputbuffer[0] e il codice comando su outputbuffer[2]
                // output_buffer[1]=MioSwitch;//per debug
                  output_buffer[2]=CmdSwitch | kAnswer;
                  if(!mHIDTxIsBusy())  HIDTxReport((char*)output_buffer);
                
                 
      } //if miosw
 
 }*/
 }

volatile unsigned char Cont=0;
/***************************************************************************************/
void
MyIntHandler ()
{
if(INTCONbits.INT0IF)
{Cont++;
INTCONbits.INT0IF=0; 

output_buffer[0]=Cont;//payload per debug
output_buffer[1]=1;//payload per debug;
output_buffer[2]=2;
 output_buffer[3]=0;
lcd_goto(0);
printf("%d    ",Cont);
      if(!mHIDTxIsBusy())  HIDTxReport((char*)output_buffer);
              //   else PutInFIFO((char*)output_buffer); //riprova al giro dopo del mainloop
 
   

} 

}





